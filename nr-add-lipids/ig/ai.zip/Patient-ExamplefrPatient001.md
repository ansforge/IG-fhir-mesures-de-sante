# ExamplefrPatient001 - Guide d'implémentation FHIR - Mesures de santé v3.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ExamplefrPatient001**

## Example Patient: ExamplefrPatient001

Pierre Jean Durand (official) Male, Date de Naissance :1974-12-25 ( urn:oid:1.2.250.1.213.1.4.8#123456789012244 (use: official, ))

-------

| | | | |
| :--- | :--- | :--- | :--- |
| Actif : | true | Décédé : | false |
| Coordonnées | * ph: 01 23 24 67 89(Home)
* ph: 01 99 88 77 66(Work)
* ph: 06 80 55 34 33(Mobile)
* 367 rue Troussier, 45100 Orléans, France(home)
 | | |



## Resource Content

```json
{
  "resourceType" : "Patient",
  "id" : "ExamplefrPatient001",
  "identifier" : [
    {
      "use" : "official",
      "system" : "urn:oid:1.2.250.1.213.1.4.8",
      "value" : "123456789012244"
    }
  ],
  "active" : true,
  "name" : [
    {
      "use" : "official",
      "family" : "Durand",
      "given" : ["Pierre", "Jean"]
    }
  ],
  "telecom" : [
    {
      "system" : "phone",
      "value" : "01 23 24 67 89",
      "use" : "home"
    },
    {
      "system" : "phone",
      "value" : "01 99 88 77 66",
      "use" : "work",
      "rank" : 1
    },
    {
      "system" : "phone",
      "value" : "06 80 55 34 33",
      "use" : "mobile",
      "rank" : 2
    }
  ],
  "gender" : "male",
  "birthDate" : "1974-12-25",
  "deceasedBoolean" : false,
  "address" : [
    {
      "use" : "home",
      "type" : "both",
      "text" : "367 rue Troussier, 45100 Orléans, France",
      "line" : ["367 rue Troussier"],
      "city" : "Orléans",
      "postalCode" : "45100",
      "period" : {
        "start" : "2018-06-01"
      }
    }
  ]
}

```
