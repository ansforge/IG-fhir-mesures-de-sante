# bundle-example-bio - Guide d'implémentation FHIR - Mesures de santé v3.1.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **bundle-example-bio**

## Example Bundle: bundle-example-bio



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "bundle-example-bio",
  "meta" : {
    "profile" : [
      "https://interop.esante.gouv.fr/ig/fhir/mesures/StructureDefinition/mesures-bundle-flux-alimentation-biologie"
    ]
  },
  "type" : "transaction",
  "entry" : [
    {
      "fullUrl" : "urn:uuid:25207dab-e2f1-4513-a499-48e508847382",
      "resource" : {
        "resourceType" : "DiagnosticReport",
        "id" : "cholesterol-dr",
        "meta" : {
          "profile" : [
            "https://interop.esante.gouv.fr/ig/fhir/mesures/StructureDefinition/mesures-diagnostic-report"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"DiagnosticReport_cholesterol-dr\"> </a><p class=\"res-header-id\"><b>Narratif généré : RapportDiagnostique cholesterol-dr</b></p><a name=\"cholesterol-dr\"> </a><a name=\"hccholesterol-dr\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-mesures-diagnostic-report.html\">DiagnosticReport mesures biologie</a></p></div><h2><span title=\"Codes :{http://loinc.org 11502-2}\">Compte rendu du laboratoire [Recherche] Patient ; Document</span> </h2><table class=\"grid\"/><p><b>Détails du rapport</b></p><table class=\"grid\"><tr><td><b>Code</b></td><td><b>Valeur</b></td><td><b>Plage de référence</b></td><td><b>Drapeaux</b></td><td><b>When For</b></td></tr><tr><td><a href=\"Observation-cholesterol-total-example.html\"><span title=\"Codes :{http://loinc.org 2093-3}\">Cholestérol [Masse/Volume] Sérum/Plasma ; Numérique</span></a></td><td>0.4 mmol/L<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMmmol/L = 'mmol/L')</span></td><td>2.8 mmol/L<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMmmol/L = 'mmol/L')</span> - 11.1 mmol/L<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMmmol/L = 'mmol/L')</span></td><td>Final</td><td>2024-10-15</td></tr><tr><td><a href=\"Observation-cholesterol-hdl-example.html\"><span title=\"Codes :{http://loinc.org 2085-9}\">HDL Cholesterol</span></a></td><td>2.8 mmol/L<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMmmol/L = 'mmol/L')</span></td><td>&gt;3.1 mmol/L<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMmmol/L = 'mmol/L')</span></td><td>Final</td><td>2024-10-15</td></tr><tr><td><a href=\"Observation-cholesterol-ldl-example.html\"><span title=\"Codes :{http://loinc.org 2089-1}\">LDL Cholesterol</span></a></td><td>7.8 mmol/L<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMmmol/L = 'mmol/L')</span></td><td>&lt;2.6 mmol/L<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMmmol/L = 'mmol/L')</span></td><td>Final</td><td>2024-10-15</td></tr><tr><td><a href=\"Observation-cholesterol-trigly-example.html\"><span title=\"Codes :{http://loinc.org 2571-8}\">LDL Cholesterol</span></a></td><td>5.6 mmol/L<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMmmol/L = 'mmol/L')</span></td><td>2.8 mmol/L<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMmmol/L = 'mmol/L')</span> - 21.1 mmol/L<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMmmol/L = 'mmol/L')</span></td><td>Final</td><td>2024-10-15</td></tr><tr><td><a href=\"Observation-glycemia-example.html\"><span title=\"Codes :{https://mos.esante.gouv.fr/NOS/TRE_A04-Loinc/FHIR/TRE-A04-Loinc 4548-4}\">Hémoglobine A1c %</span></a></td><td>92 milligramme par décilitre<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMmg/dL = 'mg/dL')</span></td><td>70 milligramme par décilitre<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMmg/dL = 'mg/dL')</span> - 100 milligramme par décilitre<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMmg/dL = 'mg/dL')</span></td><td>Final</td><td>2022-11-06</td></tr></table></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "11502-2",
              "display" : "Compte rendu du laboratoire [Recherche] Patient ; Document"
            }
          ]
        },
        "result" : [
          {
            "reference" : "Observation/cholesterol-total-example"
          },
          {
            "reference" : "Observation/cholesterol-hdl-example"
          },
          {
            "reference" : "Observation/cholesterol-ldl-example"
          },
          {
            "reference" : "Observation/cholesterol-trigly-example"
          },
          {
            "reference" : "Observation/glycemia-example"
          }
        ]
      },
      "request" : {
        "method" : "POST",
        "url" : "DiagnosticReport"
      }
    },
    {
      "fullUrl" : "urn:uuid:0f6a9f7f-d307-4497-b7e3-2059dc7344d4",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "cholesterol-ldl-example",
        "meta" : {
          "profile" : [
            "https://interop.esante.gouv.fr/ig/fhir/mesures/StructureDefinition/mesures-observation-cholesterol-ldl"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_cholesterol-ldl-example\"> </a><p class=\"res-header-id\"><b>Narratif généré : Observation cholesterol-ldl-example</b></p><a name=\"cholesterol-ldl-example\"> </a><a name=\"hccholesterol-ldl-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-mesures-observation-cholesterol-ldl.html\">Cholestérol - LDL</a></p></div><blockquote><p><b>Valeur originale</b></p><ul><li>has-been-converted: true</li><li>original-code: <span title=\"Codes :{http://loinc.org 2089-1}\">Cholesterol in LDL [Mass/volume] in Serum or Plasma</span></li><li>original-value: 3.02 g/L<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMg/L = 'g/L')</span></li></ul></blockquote><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes :{http://loinc.org 2089-1}\">LDL Cholesterol</span></p><p><b>subject</b>: <a href=\"Patient-ExamplefrPatient001.html\">Pierre Durand</a></p><p><b>effective</b>: 2024-10-15</p><p><b>value</b>: 7.8 mmol/L<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMmmol/L = 'mmol/L')</span></p><p><b>method</b>: <span title=\"Codes :{https://smt.esante.gouv.fr/fhir/ValueSet/1.2.250.1.213.1.1.5.789 DEG}\">DEG</span></p><h3>ReferenceRanges</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>High</b></td></tr><tr><td style=\"display: none\">*</td><td>2.6 mmol/L<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMmmol/L = 'mmol/L')</span></td></tr></table></div>"
        },
        "extension" : [
          {
            "extension" : [
              {
                "url" : "has-been-converted",
                "valueBoolean" : true
              },
              {
                "url" : "original-code",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "http://loinc.org",
                      "code" : "2089-1",
                      "display" : "Cholesterol in LDL [Mass/volume] in Serum or Plasma"
                    }
                  ]
                }
              },
              {
                "url" : "original-value",
                "valueQuantity" : {
                  "value" : 3.02,
                  "unit" : "g/L",
                  "system" : "http://unitsofmeasure.org",
                  "code" : "g/L"
                }
              }
            ],
            "url" : "https://interop.esante.gouv.fr/ig/fhir/mesures/StructureDefinition/mesures-original-data"
          }
        ],
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "2089-1",
              "display" : "LDL Cholesterol"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/ExamplefrPatient001",
          "type" : "Patient",
          "display" : "Pierre Durand"
        },
        "effectiveDateTime" : "2024-10-15",
        "valueQuantity" : {
          "value" : 7.8,
          "unit" : "mmol/L",
          "system" : "http://unitsofmeasure.org",
          "code" : "mmol/L"
        },
        "method" : {
          "coding" : [
            {
              "system" : "https://smt.esante.gouv.fr/fhir/ValueSet/1.2.250.1.213.1.1.5.789",
              "code" : "DEG"
            }
          ]
        },
        "referenceRange" : [
          {
            "high" : {
              "value" : 2.6,
              "unit" : "mmol/L",
              "system" : "http://unitsofmeasure.org",
              "code" : "mmol/L"
            }
          }
        ]
      },
      "request" : {
        "method" : "POST",
        "url" : "Observation"
      }
    },
    {
      "fullUrl" : "urn:uuid:7375171a-805e-440d-aa55-eb0ced35625c",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "cholesterol-hdl-example",
        "meta" : {
          "profile" : [
            "https://interop.esante.gouv.fr/ig/fhir/mesures/StructureDefinition/mesures-observation-cholesterol-hdl"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_cholesterol-hdl-example\"> </a><p class=\"res-header-id\"><b>Narratif généré : Observation cholesterol-hdl-example</b></p><a name=\"cholesterol-hdl-example\"> </a><a name=\"hccholesterol-hdl-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-mesures-observation-cholesterol-hdl.html\">Cholestérol - HDL</a></p></div><blockquote><p><b>Valeur originale</b></p><ul><li>has-been-converted: true</li><li>original-code: <span title=\"Codes :{http://loinc.org 2085-9}\">Cholesterol in HDL [Mass/volume] in Serum or Plasma</span></li><li>original-value: 1.08 g/L<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMg/L = 'g/L')</span></li></ul></blockquote><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes :{http://loinc.org 2085-9}\">HDL Cholesterol</span></p><p><b>subject</b>: <a href=\"Patient-ExamplefrPatient001.html\">Pierre Durand</a></p><p><b>effective</b>: 2024-10-15</p><p><b>value</b>: 2.8 mmol/L<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMmmol/L = 'mmol/L')</span></p><p><b>method</b>: <span title=\"Codes :{https://smt.esante.gouv.fr/fhir/ValueSet/1.2.250.1.213.1.1.5.789 DEG}\">DEG</span></p><h3>ReferenceRanges</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Low</b></td></tr><tr><td style=\"display: none\">*</td><td>3.1 mmol/L<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMmmol/L = 'mmol/L')</span></td></tr></table></div>"
        },
        "extension" : [
          {
            "extension" : [
              {
                "url" : "has-been-converted",
                "valueBoolean" : true
              },
              {
                "url" : "original-code",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "http://loinc.org",
                      "code" : "2085-9",
                      "display" : "Cholesterol in HDL [Mass/volume] in Serum or Plasma"
                    }
                  ]
                }
              },
              {
                "url" : "original-value",
                "valueQuantity" : {
                  "value" : 1.08,
                  "unit" : "g/L",
                  "system" : "http://unitsofmeasure.org",
                  "code" : "g/L"
                }
              }
            ],
            "url" : "https://interop.esante.gouv.fr/ig/fhir/mesures/StructureDefinition/mesures-original-data"
          }
        ],
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "2085-9",
              "display" : "HDL Cholesterol"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/ExamplefrPatient001",
          "type" : "Patient",
          "display" : "Pierre Durand"
        },
        "effectiveDateTime" : "2024-10-15",
        "valueQuantity" : {
          "value" : 2.8,
          "unit" : "mmol/L",
          "system" : "http://unitsofmeasure.org",
          "code" : "mmol/L"
        },
        "method" : {
          "coding" : [
            {
              "system" : "https://smt.esante.gouv.fr/fhir/ValueSet/1.2.250.1.213.1.1.5.789",
              "code" : "DEG"
            }
          ]
        },
        "referenceRange" : [
          {
            "low" : {
              "value" : 3.1,
              "unit" : "mmol/L",
              "system" : "http://unitsofmeasure.org",
              "code" : "mmol/L"
            }
          }
        ]
      },
      "request" : {
        "method" : "POST",
        "url" : "Observation"
      }
    },
    {
      "fullUrl" : "urn:uuid:1cd043f1-996c-49e8-bb03-b02a865505af",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "cholesterol-trigly-example",
        "meta" : {
          "profile" : [
            "https://interop.esante.gouv.fr/ig/fhir/mesures/StructureDefinition/mesures-observation-cholesterol-trigly"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_cholesterol-trigly-example\"> </a><p class=\"res-header-id\"><b>Narratif généré : Observation cholesterol-trigly-example</b></p><a name=\"cholesterol-trigly-example\"> </a><a name=\"hccholesterol-trigly-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-mesures-observation-cholesterol-trigly.html\">Cholestérol - triglycerides</a></p></div><blockquote><p><b>Valeur originale</b></p><ul><li>has-been-converted: true</li><li>original-code: <span title=\"Codes :{http://loinc.org 2571-8}\">Triglyceride [Mass/volume] in Serum or Plasma</span></li><li>original-value: 4.9 g/L<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMg/L = 'g/L')</span></li></ul></blockquote><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes :{http://loinc.org 2571-8}\">LDL Cholesterol</span></p><p><b>subject</b>: <a href=\"Patient-ExamplefrPatient001.html\">Pierre Durand</a></p><p><b>effective</b>: 2024-10-15</p><p><b>value</b>: 5.6 mmol/L<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMmmol/L = 'mmol/L')</span></p><p><b>method</b>: <span title=\"Codes :{https://smt.esante.gouv.fr/fhir/ValueSet/1.2.250.1.213.1.1.5.789 DEG}\">DEG</span></p><h3>ReferenceRanges</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Low</b></td><td><b>High</b></td></tr><tr><td style=\"display: none\">*</td><td>2.8 mmol/L<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMmmol/L = 'mmol/L')</span></td><td>21.1 mmol/L<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMmmol/L = 'mmol/L')</span></td></tr></table></div>"
        },
        "extension" : [
          {
            "extension" : [
              {
                "url" : "has-been-converted",
                "valueBoolean" : true
              },
              {
                "url" : "original-code",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "http://loinc.org",
                      "code" : "2571-8",
                      "display" : "Triglyceride [Mass/volume] in Serum or Plasma"
                    }
                  ]
                }
              },
              {
                "url" : "original-value",
                "valueQuantity" : {
                  "value" : 4.9,
                  "unit" : "g/L",
                  "system" : "http://unitsofmeasure.org",
                  "code" : "g/L"
                }
              }
            ],
            "url" : "https://interop.esante.gouv.fr/ig/fhir/mesures/StructureDefinition/mesures-original-data"
          }
        ],
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "2571-8",
              "display" : "LDL Cholesterol"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/ExamplefrPatient001",
          "type" : "Patient",
          "display" : "Pierre Durand"
        },
        "effectiveDateTime" : "2024-10-15",
        "valueQuantity" : {
          "value" : 5.6,
          "unit" : "mmol/L",
          "system" : "http://unitsofmeasure.org",
          "code" : "mmol/L"
        },
        "method" : {
          "coding" : [
            {
              "system" : "https://smt.esante.gouv.fr/fhir/ValueSet/1.2.250.1.213.1.1.5.789",
              "code" : "DEG"
            }
          ]
        },
        "referenceRange" : [
          {
            "low" : {
              "value" : 2.8,
              "unit" : "mmol/L",
              "system" : "http://unitsofmeasure.org",
              "code" : "mmol/L"
            },
            "high" : {
              "value" : 21.1,
              "unit" : "mmol/L",
              "system" : "http://unitsofmeasure.org",
              "code" : "mmol/L"
            }
          }
        ]
      },
      "request" : {
        "method" : "POST",
        "url" : "Observation"
      }
    },
    {
      "fullUrl" : "urn:uuid:91bc2d03-5406-490c-89f5-23cce837494d",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "cholesterol-total-example",
        "meta" : {
          "profile" : [
            "https://interop.esante.gouv.fr/ig/fhir/mesures/StructureDefinition/mesures-observation-cholesterol-total"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_cholesterol-total-example\"> </a><p class=\"res-header-id\"><b>Narratif généré : Observation cholesterol-total-example</b></p><a name=\"cholesterol-total-example\"> </a><a name=\"hccholesterol-total-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-mesures-observation-cholesterol-total.html\">Cholestérol - total</a></p></div><blockquote><p><b>Valeur originale</b></p><ul><li>has-been-converted: true</li><li>original-code: <span title=\"Codes :{http://loinc.org 2093-3}\">Cholesterol [Mass/volume] in Serum or Plasma</span></li><li>original-value: 0.155 g/L<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMg/L = 'g/L')</span></li></ul></blockquote><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes :{http://loinc.org 2093-3}\">Cholestérol [Masse/Volume] Sérum/Plasma ; Numérique</span></p><p><b>subject</b>: <a href=\"Patient-ExamplefrPatient001.html\">Pierre Durand</a></p><p><b>effective</b>: 2024-10-15</p><p><b>value</b>: 0.4 mmol/L<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMmmol/L = 'mmol/L')</span></p><p><b>method</b>: <span title=\"Codes :{https://smt.esante.gouv.fr/fhir/ValueSet/1.2.250.1.213.1.1.5.789 DEG}\">DEG</span></p><h3>ReferenceRanges</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Low</b></td><td><b>High</b></td></tr><tr><td style=\"display: none\">*</td><td>2.8 mmol/L<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMmmol/L = 'mmol/L')</span></td><td>11.1 mmol/L<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMmmol/L = 'mmol/L')</span></td></tr></table></div>"
        },
        "extension" : [
          {
            "extension" : [
              {
                "url" : "has-been-converted",
                "valueBoolean" : true
              },
              {
                "url" : "original-code",
                "valueCodeableConcept" : {
                  "coding" : [
                    {
                      "system" : "http://loinc.org",
                      "code" : "2093-3",
                      "display" : "Cholesterol [Mass/volume] in Serum or Plasma"
                    }
                  ]
                }
              },
              {
                "url" : "original-value",
                "valueQuantity" : {
                  "value" : 0.155,
                  "unit" : "g/L",
                  "system" : "http://unitsofmeasure.org",
                  "code" : "g/L"
                }
              }
            ],
            "url" : "https://interop.esante.gouv.fr/ig/fhir/mesures/StructureDefinition/mesures-original-data"
          }
        ],
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "2093-3",
              "display" : "Cholestérol [Masse/Volume] Sérum/Plasma ; Numérique"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/ExamplefrPatient001",
          "type" : "Patient",
          "display" : "Pierre Durand"
        },
        "effectiveDateTime" : "2024-10-15",
        "valueQuantity" : {
          "value" : 0.4,
          "unit" : "mmol/L",
          "system" : "http://unitsofmeasure.org",
          "code" : "mmol/L"
        },
        "method" : {
          "coding" : [
            {
              "system" : "https://smt.esante.gouv.fr/fhir/ValueSet/1.2.250.1.213.1.1.5.789",
              "code" : "DEG"
            }
          ]
        },
        "referenceRange" : [
          {
            "low" : {
              "value" : 2.8,
              "unit" : "mmol/L",
              "system" : "http://unitsofmeasure.org",
              "code" : "mmol/L"
            },
            "high" : {
              "value" : 11.1,
              "unit" : "mmol/L",
              "system" : "http://unitsofmeasure.org",
              "code" : "mmol/L"
            }
          }
        ]
      },
      "request" : {
        "method" : "POST",
        "url" : "Observation"
      }
    },
    {
      "fullUrl" : "urn:uuid:eae3dfd3-ccc1-438e-b8fe-fe725dce7947",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "glycemia-example",
        "meta" : {
          "profile" : [
            "https://interop.esante.gouv.fr/ig/fhir/mesures/StructureDefinition/mesures-observation-glucose"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_glycemia-example\"> </a><p class=\"res-header-id\"><b>Narratif généré : Observation glycemia-example</b></p><a name=\"glycemia-example\"> </a><a name=\"hcglycemia-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-mesures-observation-glucose.html\">Glycémie</a></p></div><p><b>Raison de la mesure</b>: Malaise du patient</p><p><b>Moment de la mesure</b>: <span title=\"Codes :{https://mos.esante.gouv.fr/NOS/TRE_A04-Loinc/FHIR/TRE-A04-Loinc 16915-1}\">Glucose post prandial</span></p><p><b>Nombre de jours</b>: <span title=\"Codes :{https://mos.esante.gouv.fr/NOS/TRE_R308-TAASIP/FHIR/TRE-R308-TAASIP GEN-275}\">7j</span></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes :{http://terminology.hl7.org/CodeSystem/observation-category vital-signs}\">Vital Signs</span></p><p><b>code</b>: <span title=\"Codes :{https://mos.esante.gouv.fr/NOS/TRE_A04-Loinc/FHIR/TRE-A04-Loinc 4548-4}\">Hémoglobine A1c %</span></p><p><b>subject</b>: <a href=\"Patient-ExamplefrPatient001.html\">Pierre Durand</a></p><p><b>effective</b>: 2022-11-06</p><p><b>value</b>: 92 milligramme par décilitre<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMmg/dL = 'mg/dL')</span></p><h3>ReferenceRanges</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Low</b></td><td><b>High</b></td></tr><tr><td style=\"display: none\">*</td><td>70 milligramme par décilitre<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMmg/dL = 'mg/dL')</span></td><td>100 milligramme par décilitre<span style=\"background: LightGoldenRodYellow\"> (Détails : code UCUMmg/dL = 'mg/dL')</span></td></tr></table></div>"
        },
        "extension" : [
          {
            "url" : "https://interop.esante.gouv.fr/ig/fhir/mesures/StructureDefinition/mesures-reason-for-measurement",
            "valueString" : "Malaise du patient"
          },
          {
            "url" : "https://interop.esante.gouv.fr/ig/fhir/mesures/StructureDefinition/mesures-moment-of-measurement",
            "valueCodeableConcept" : {
              "coding" : [
                {
                  "system" : "https://mos.esante.gouv.fr/NOS/TRE_A04-Loinc/FHIR/TRE-A04-Loinc",
                  "code" : "16915-1",
                  "display" : "Glucose post prandial"
                }
              ]
            }
          },
          {
            "url" : "https://interop.esante.gouv.fr/ig/fhir/mesures/StructureDefinition/mesures-number-of-days",
            "valueCodeableConcept" : {
              "coding" : [
                {
                  "system" : "https://mos.esante.gouv.fr/NOS/TRE_R308-TAASIP/FHIR/TRE-R308-TAASIP",
                  "code" : "GEN-275",
                  "display" : "7j"
                }
              ]
            }
          }
        ],
        "status" : "final",
        "category" : [
          {
            "coding" : [
              {
                "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
                "code" : "vital-signs"
              }
            ]
          }
        ],
        "code" : {
          "coding" : [
            {
              "system" : "https://mos.esante.gouv.fr/NOS/TRE_A04-Loinc/FHIR/TRE-A04-Loinc",
              "code" : "4548-4"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/ExamplefrPatient001",
          "type" : "Patient",
          "display" : "Pierre Durand"
        },
        "effectiveDateTime" : "2022-11-06",
        "valueQuantity" : {
          "value" : 92,
          "unit" : "milligramme par décilitre",
          "system" : "http://unitsofmeasure.org",
          "code" : "mg/dL"
        },
        "referenceRange" : [
          {
            "low" : {
              "value" : 70,
              "unit" : "milligramme par décilitre",
              "system" : "http://unitsofmeasure.org",
              "code" : "mg/dL"
            },
            "high" : {
              "value" : 100,
              "unit" : "milligramme par décilitre",
              "system" : "http://unitsofmeasure.org",
              "code" : "mg/dL"
            }
          }
        ]
      },
      "request" : {
        "method" : "POST",
        "url" : "Observation"
      }
    }
  ]
}

```
