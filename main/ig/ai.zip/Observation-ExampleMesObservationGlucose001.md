# ExampleMesObservationGlucose001 - Guide d'implémentation FHIR - Mesures de santé v3.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ExampleMesObservationGlucose001**

## Example Observation: ExampleMesObservationGlucose001

Profil: [Glycémie](StructureDefinition-mesures-observation-glucose.md)

> **Origine de la donnée**
* hasBeenConverted: true
* documentId: `http://system-dmp-example.fr`/6f9b7d72-2a8e-4a35-b95a-c2d31b279c7b
* originalCode: Glucose [Masse/Volume] Sérum/Plasma ; Numérique

**Raison de la mesure**: Malaise du patient

**Moment de la mesure**: Glucose post prandial

**Nombre de jours**: 7j

**status**: Final

**category**: Vital Signs

**code**: Hémoglobine A1c %

**subject**: [Pierre Durand](Patient-ExamplefrPatient001.md)

**effective**: 2022-11-06

**value**: 92 milligramme par décilitre(Details: UCUM codemg/dL = 'mg/dL')

### ReferenceRanges

| | | |
| :--- | :--- | :--- |
| - | **Low** | **High** |
| * | 70 milligramme par décilitre(Details: UCUM codemg/dL = 'mg/dL') | 100 milligramme par décilitre(Details: UCUM codemg/dL = 'mg/dL') |



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "ExampleMesObservationGlucose001",
  "meta" : {
    "profile" : [
      "https://interop.esante.gouv.fr/ig/fhir/mesures/StructureDefinition/mesures-observation-glucose"
    ]
  },
  "extension" : [
    {
      "extension" : [
        {
          "url" : "hasBeenConverted",
          "valueBoolean" : true
        },
        {
          "url" : "documentId",
          "valueIdentifier" : {
            "system" : "http://system-dmp-example.fr",
            "value" : "6f9b7d72-2a8e-4a35-b95a-c2d31b279c7b"
          }
        },
        {
          "url" : "originalCode",
          "valueCodeableConcept" : {
            "coding" : [
              {
                "system" : "http://loinc.org",
                "code" : "2345-7"
              }
            ]
          }
        }
      ],
      "url" : "https://interop.esante.gouv.fr/ig/fhir/mesures/StructureDefinition/mesures-origin-of-data"
    },
    {
      "url" : "https://interop.esante.gouv.fr/ig/fhir/mesures/StructureDefinition/mesures-reason-for-measurement",
      "valueString" : "Malaise du patient"
    },
    {
      "url" : "https://interop.esante.gouv.fr/ig/fhir/mesures/StructureDefinition/mesures-moment-of-measurement",
      "valueCodeableConcept" : {
        "coding" : [
          {
            "system" : "https://mos.esante.gouv.fr/NOS/TRE_A04-Loinc/FHIR/TRE-A04-Loinc",
            "code" : "16915-1",
            "display" : "Glucose post prandial"
          }
        ]
      }
    },
    {
      "url" : "https://interop.esante.gouv.fr/ig/fhir/mesures/StructureDefinition/mesures-number-of-days",
      "valueCodeableConcept" : {
        "coding" : [
          {
            "system" : "https://mos.esante.gouv.fr/NOS/TRE_R308-TAASIP/FHIR/TRE-R308-TAASIP",
            "code" : "GEN-275",
            "display" : "7j"
          }
        ]
      }
    }
  ],
  "status" : "final",
  "category" : [
    {
      "coding" : [
        {
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "vital-signs"
        }
      ]
    }
  ],
  "code" : {
    "coding" : [
      {
        "system" : "https://mos.esante.gouv.fr/NOS/TRE_A04-Loinc/FHIR/TRE-A04-Loinc",
        "code" : "4548-4"
      }
    ]
  },
  "subject" : {
    "reference" : "Patient/ExamplefrPatient001",
    "type" : "Patient",
    "display" : "Pierre Durand"
  },
  "effectiveDateTime" : "2022-11-06",
  "valueQuantity" : {
    "value" : 92,
    "unit" : "milligramme par décilitre",
    "system" : "http://unitsofmeasure.org",
    "code" : "mg/dL"
  },
  "referenceRange" : [
    {
      "low" : {
        "value" : 70,
        "unit" : "milligramme par décilitre",
        "system" : "http://unitsofmeasure.org",
        "code" : "mg/dL"
      },
      "high" : {
        "value" : 100,
        "unit" : "milligramme par décilitre",
        "system" : "http://unitsofmeasure.org",
        "code" : "mg/dL"
      }
    }
  ]
}

```
