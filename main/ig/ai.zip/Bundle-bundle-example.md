# bundle-example - Guide d'implémentation FHIR - Mesures de santé v3.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **bundle-example**

## Example Bundle: bundle-example

Profil: [Bundle d'alimentation](StructureDefinition-mesures-bundle-flux-alimentation.md)

Bundle bundle-example de type transaction

-------

Entry 1 - fullUrl = urn:uuid:5138af77-df7e-4b9d-ba17-07ba3ebb950a

Ressource Observation :

> 

Profil: [Poids](StructureDefinition-mesures-fr-observation-body-weight.md)

**Raison de la mesure**: Mon nouveau poids !**status**: Final**category**:Vital Signs**code**:Body weight**subject**: Identifier:`urn:oid:1.2.840.10004.1.1.1.0.0.1.0.0.1.2560`/id-value**effective**: 2022-08-22 01:56:16+0100**value**: 71 kg(Details: UCUM codekg = 'kg')**device**:[Device : identifier = IEEE 11073 System Identifier; manufacturer = OMRONHEALTHCARE; modelNumber = HEM-9200T; type = MDC_MOC_VMS_MDS_SIMP](Bundle-bundle-example.md#Device_d36bfdb6-b1b1-4efd-9cb9-d217a8696575)

Requête :

```
POST Observation

```

-------

Entry 2 - fullUrl = urn:uuid:d36bfdb6-b1b1-4efd-9cb9-d217a8696575

Ressource Device :

> 

Profil: [PhdDevice](http://hl7.org/fhir/uv/phd/STU1/StructureDefinition-PhdDevice.html)

**identifier**: IEEE 11073 System Identifier/FE-ED-AB-AA-DE-AD-77-C5**manufacturer**: OMRONHEALTHCARE**modelNumber**: HEM-9200T**type**:MDC_MOC_VMS_MDS_SIMP

Requête :

```
POST Device

```



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "bundle-example",
  "meta" : {
    "profile" : [
      "https://interop.esante.gouv.fr/ig/fhir/mesures/StructureDefinition/mesures-bundle-flux-alimentation"
    ]
  },
  "type" : "transaction",
  "entry" : [
    {
      "fullUrl" : "urn:uuid:5138af77-df7e-4b9d-ba17-07ba3ebb950a",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "5138af77-df7e-4b9d-ba17-07ba3ebb950a",
        "meta" : {
          "profile" : [
            "https://interop.esante.gouv.fr/ig/fhir/mesures/StructureDefinition/mesures-fr-observation-body-weight"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_5138af77-df7e-4b9d-ba17-07ba3ebb950a\"> </a><p class=\"res-header-id\"><b>Narratif généré : Observation 5138af77-df7e-4b9d-ba17-07ba3ebb950a</b></p><a name=\"5138af77-df7e-4b9d-ba17-07ba3ebb950a\"> </a><a name=\"hc5138af77-df7e-4b9d-ba17-07ba3ebb950a\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-mesures-fr-observation-body-weight.html\">Poids</a></p></div><p><b>Raison de la mesure</b>: Mon nouveau poids !</p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category vital-signs}\">Vital Signs</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 29463-7}\">Body weight</span></p><p><b>subject</b>: Identifier: <code>urn:oid:1.2.840.10004.1.1.1.0.0.1.0.0.1.2560</code>/id-value</p><p><b>effective</b>: 2022-08-22 01:56:16+0100</p><p><b>value</b>: 71 kg<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codekg = 'kg')</span></p><p><b>device</b>: <a href=\"Bundle-bundle-example.html#Device_d36bfdb6-b1b1-4efd-9cb9-d217a8696575\">Device : identifier = IEEE 11073 System Identifier; manufacturer = OMRONHEALTHCARE; modelNumber = HEM-9200T; type = MDC_MOC_VMS_MDS_SIMP</a></p></div>"
        },
        "extension" : [
          {
            "url" : "https://interop.esante.gouv.fr/ig/fhir/mesures/StructureDefinition/mesures-reason-for-measurement",
            "valueString" : "Mon nouveau poids !"
          }
        ],
        "status" : "final",
        "category" : [
          {
            "coding" : [
              {
                "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
                "code" : "vital-signs"
              }
            ]
          }
        ],
        "code" : {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "29463-7",
              "display" : "Body weight"
            }
          ]
        },
        "subject" : {
          "identifier" : {
            "system" : "urn:oid:1.2.840.10004.1.1.1.0.0.1.0.0.1.2560",
            "value" : "id-value"
          }
        },
        "effectiveDateTime" : "2022-08-22T01:56:16+01:00",
        "valueQuantity" : {
          "value" : 71,
          "unit" : "kg",
          "system" : "http://unitsofmeasure.org",
          "code" : "kg"
        },
        "device" : {
          "reference" : "Device/d36bfdb6-b1b1-4efd-9cb9-d217a8696575"
        }
      },
      "request" : {
        "method" : "POST",
        "url" : "Observation"
      }
    },
    {
      "fullUrl" : "urn:uuid:d36bfdb6-b1b1-4efd-9cb9-d217a8696575",
      "resource" : {
        "resourceType" : "Device",
        "id" : "d36bfdb6-b1b1-4efd-9cb9-d217a8696575",
        "meta" : {
          "profile" : ["http://hl7.org/fhir/uv/phd/StructureDefinition/PhdDevice"]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Device_d36bfdb6-b1b1-4efd-9cb9-d217a8696575\"> </a><p class=\"res-header-id\"><b>Narratif généré : Dispositif d36bfdb6-b1b1-4efd-9cb9-d217a8696575</b></p><a name=\"d36bfdb6-b1b1-4efd-9cb9-d217a8696575\"> </a><a name=\"hcd36bfdb6-b1b1-4efd-9cb9-d217a8696575\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"http://hl7.org/fhir/uv/phd/STU1/StructureDefinition-PhdDevice.html\">PhdDevice</a></p></div><p><b>identifier</b>: IEEE 11073 System Identifier/FE-ED-AB-AA-DE-AD-77-C5</p><p><b>manufacturer</b>: OMRONHEALTHCARE</p><h3>DeviceNames</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>Ma balance</td><td>Patient Reported name</td></tr></table><p><b>modelNumber</b>: HEM-9200T</p><p><b>type</b>: <span title=\"Codes:{urn:iso:std:iso:11073:10101 65573}\">MDC_MOC_VMS_MDS_SIMP</span></p><h3>Specializations</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>SystemType</b></td><td><b>Version</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{urn:iso:std:iso:11073:10101 528457}\">MDC_DEV_SPEC_PROFILE_GENERIC</span></td><td>2.3</td></tr></table></div>"
        },
        "identifier" : [
          {
            "type" : {
              "coding" : [
                {
                  "system" : "http://hl7.org/fhir/uv/phd/CodeSystem/ContinuaDeviceIdentifiers",
                  "code" : "SYSID"
                }
              ]
            },
            "system" : "urn:oid:1.2.840.10004.1.1.1.0.0.1.0.0.1.2680",
            "value" : "FE-ED-AB-AA-DE-AD-77-C5"
          }
        ],
        "manufacturer" : "OMRONHEALTHCARE",
        "deviceName" : [
          {
            "name" : "Ma balance",
            "type" : "patient-reported-name"
          }
        ],
        "modelNumber" : "HEM-9200T",
        "type" : {
          "coding" : [
            {
              "system" : "urn:iso:std:iso:11073:10101",
              "code" : "65573"
            }
          ]
        },
        "specialization" : [
          {
            "systemType" : {
              "coding" : [
                {
                  "system" : "urn:iso:std:iso:11073:10101",
                  "code" : "528457"
                }
              ]
            },
            "version" : "2.3"
          }
        ]
      },
      "request" : {
        "method" : "POST",
        "url" : "Device"
      }
    }
  ]
}

```
